package data

import (
	"math/rand"
	"time"
)

type OrdenesPagoEnvio struct {
	IDOrden                       int
	EtiquetaTiempoCaptura         int64
	FechaOperacion                time.Time
	Monto                         float64
	Prioridad                     int
	TipoPago                      string
	ClaveRestreo                  string
	MedioEntrega                  string
	NombreOrdenante               string
	TipoCuentaOrdenante           int
	CuentaOrdenante               string
	RFCOrdenante                  string
	CURPOrdenante                 string
	ClaveBeneficiario             int
	NombreBeneficiario            string
	TipoCuentaBeneficiario        int
	CuentaBeneficiario            string
	RFCBeneficiario               string
	CURPBeneficiario              string
	ConceptoPago40                string
	ConceptoPago120               string
	ImporteIVA                    float64
	ReferenciaNumerica            int
	ReferenciaCobranza1           string
	ClavePago                     string
	NombreBeneficiario2           string
	TipoCuentaBeneficiario2       int
	CuentaBeneficiario2           string
	RFCBeneficiario2              string
	CURPBeneficiario2             string
	TipoOperacion                 string
	CausaDevolucion               string
	InformacionFacturas           string
	FolioInstruccionOriginal      int
	FolioPagoOriginal             int
	FechaOrdenTransferenciaOrig   time.Time
	ClaveRastreoPagOrig           string
	ReferenciaNumPagOrig          int
	TipoCtaOrdenantePagOrig       int
	CtaOrdenantePagOrig           string
	ConceptoPagOrig               string
	MontoPagOrig                  float64
	MontoInteresesPagados         float64
	IndicadorBeneficiarioRecursos int
	NumCelOrdenante               string
	DigitoVerifDispoOrdenante     int
	NumCelBeneficiario            string
	DigitoVerifDispoBeneficiario  int
	FolioEsqCobroDigital          string
	PagoComisionPorTransferencia  int
	MontoComisionPorTransferencia float64
	NumSerieCertificadoEnvio      string
	FechaLimitePago               time.Time
	UETRSwift                     string
	CampoSwift1                   string
	CampoSwift2                   string
	FirmaDigitalCliente           string
	UsuarioCaptura                string
	InstruccionPago               int
	FolioOrdenInstruccion         int
	EstadoCore                    int16
	EstadoBMX                     int16
	CodigoError                   int
	DescripcionError              string
	HuellaDigital                 string
}

func generarOrdenRandom() OrdenesPagoEnvio {
	return OrdenesPagoEnvio{
		IDOrden:                       rand.Intn(1000),
		EtiquetaTiempoCaptura:         rand.Int63n(1000),
		FechaOperacion:                time.Now(),
		Monto:                         rand.Float64() * 1000,
		Prioridad:                     rand.Intn(1000),
		TipoPago:                      generateRandomString(10),
		ClaveRestreo:                  generateRandomString(10),
		MedioEntrega:                  generateRandomString(10),
		NombreOrdenante:               generateRandomString(10),
		TipoCuentaOrdenante:           rand.Intn(10),
		CuentaOrdenante:               generateRandomString(10),
		RFCOrdenante:                  generateRandomString(10),
		CURPOrdenante:                 generateRandomString(10),
		ClaveBeneficiario:             rand.Intn(1000),
		NombreBeneficiario:            generateRandomString(10),
		TipoCuentaBeneficiario:        rand.Intn(10),
		CuentaBeneficiario:            generateRandomString(10),
		RFCBeneficiario:               generateRandomString(10),
		CURPBeneficiario:              generateRandomString(10),
		ConceptoPago40:                generateRandomString(40),
		ConceptoPago120:               generateRandomString(120),
		ImporteIVA:                    rand.Float64() * 1000,
		ReferenciaNumerica:            rand.Intn(1000),
		ReferenciaCobranza1:           generateRandomString(10),
		ClavePago:                     generateRandomString(10),
		NombreBeneficiario2:           generateRandomString(10),
		TipoCuentaBeneficiario2:       rand.Intn(10),
		CuentaBeneficiario2:           generateRandomString(10),
		RFCBeneficiario2:              generateRandomString(10),
		CURPBeneficiario2:             generateRandomString(10),
		TipoOperacion:                 generateRandomString(10),
		CausaDevolucion:               generateRandomString(10),
		InformacionFacturas:           generateRandomString(10),
		FolioInstruccionOriginal:      rand.Intn(1000),
		FolioPagoOriginal:             rand.Intn(1000),
		FechaOrdenTransferenciaOrig:   time.Now(),
		ClaveRastreoPagOrig:           generateRandomString(10),
		ReferenciaNumPagOrig:          rand.Intn(1000),
		TipoCtaOrdenantePagOrig:       rand.Intn(1000),
		CtaOrdenantePagOrig:           generateRandomString(10),
		ConceptoPagOrig:               generateRandomString(10),
		MontoPagOrig:                  rand.Float64() * 1000,
		MontoInteresesPagados:         rand.Float64() * 1000,
		IndicadorBeneficiarioRecursos: rand.Intn(1000),
		NumCelOrdenante:               generateRandomString(10),
		DigitoVerifDispoOrdenante:     rand.Intn(10),
		NumCelBeneficiario:            generateRandomString(10),
		DigitoVerifDispoBeneficiario:  rand.Intn(10),
		FolioEsqCobroDigital:          generateRandomString(10),
		PagoComisionPorTransferencia:  rand.Intn(1000),
		MontoComisionPorTransferencia: rand.Float64() * 1000,
		NumSerieCertificadoEnvio:      generateRandomString(10),
		FechaLimitePago:               time.Now(),
		UETRSwift:                     generateRandomString(10),
		CampoSwift1:                   generateRandomString(10),
		CampoSwift2:                   generateRandomString(10),
		FirmaDigitalCliente:           generateRandomString(10),
		UsuarioCaptura:                generateRandomString(10),
		InstruccionPago:               rand.Intn(1000),
		FolioOrdenInstruccion:         rand.Intn(1000),
		EstadoCore:                    2,
		EstadoBMX:                     2,
		CodigoError:                   0,
		DescripcionError:              generateRandomString(10),
		HuellaDigital:                 generateRandomString(10),
	}
}

func generateRandomString(length int) string {
	const charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
	seededRand := rand.New(rand.NewSource(time.Now().UnixNano()))
	b := make([]byte, length)
	for i := range b {
		b[i] = charset[seededRand.Intn(len(charset))]
	}
	return string(b)
}
