package main

import (
	DBDATABASE "Prueba_Volumen/config"
	"Prueba_Volumen/internal/service"
	"fmt"
	"math/rand"
	"time"
)

func main() {
	// Conexión a la base de datos
	db := DBDATABASE.DatabaseConfig{}
	database, errdb := db.ConectarSQLServer()

	if errdb != nil {
		fmt.Println("Error al conectar a SQL Server:", errdb)
		return
	}

	rand.Seed(time.Now().UnixNano())
	for i := 0; i < 1000; i++ {
		dato := service
		fmt.Println(dato)
	}

}
