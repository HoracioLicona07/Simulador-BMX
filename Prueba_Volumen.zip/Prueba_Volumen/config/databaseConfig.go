package db

import (
	"Prueba_Volumen/internal/envs"
	"database/sql"
	"fmt"

	_ "github.com/denisenkom/go-mssqldb"
	"gorm.io/gorm"
)

type DatabaseConfig struct {
	DB *gorm.DB
}

func (dbConfig *DatabaseConfig) ConectarSQLServer() (*sql.DB, error) {
	// Establece la cadena de conexión
	connString := fmt.Sprintf("server=%s;port=%s;database=%s;trusted_connection=yes;", envs.Get("DBSERVER", "server"), envs.Get("DBPORT", "port"), envs.Get("DBDATABASE", "db"))

	// Abre la conexión
	db, err := sql.Open("sqlserver", connString)
	if err != nil {
		return nil, err
	}

	// Intenta conectar
	err = db.Ping()
	if err != nil {
		return nil, err
	}

	fmt.Println("Conexión exitosa a SQL Server")
	return db, nil
}
