package service

import (
	"Prueba_Volumen/pkg/data"
	"math/rand"
	"time"
)

func GenerarOrdenRandom() data.OrdenesPagoEnvio {
	return data.OrdenesPagoEnvio{
		IDOrden:                       rand.Intn(1000),
		EtiquetaTiempoCaptura:         rand.Int63n(1000),
		FechaOperacion:                time.Now(),
		Monto:                         rand.Float64() * 1000,
		Prioridad:                     rand.Intn(1000),
		TipoPago:                      generateRandomString(10),
		ClaveRestreo:                  generateRandomString(10),
		MedioEntrega:                  generateRandomString(10),
		NombreOrdenante:               generateRandomString(10),
		TipoCuentaOrdenante:           rand.Intn(10),
		CuentaOrdenante:               generateRandomString(10),
		RFCOrdenante:                  generateRandomString(10),
		CURPOrdenante:                 generateRandomString(10),
		ClaveBeneficiario:             rand.Intn(1000),
		NombreBeneficiario:            generateRandomString(10),
		TipoCuentaBeneficiario:        rand.Intn(10),
		CuentaBeneficiario:            generateRandomString(10),
		RFCBeneficiario:               generateRandomString(10),
		CURPBeneficiario:              generateRandomString(10),
		ConceptoPago40:                generateRandomString(40),
		ConceptoPago120:               generateRandomString(120),
		ImporteIVA:                    rand.Float64() * 1000,
		ReferenciaNumerica:            rand.Intn(1000),
		ReferenciaCobranza1:           generateRandomString(10),
		ClavePago:                     generateRandomString(10),
		NombreBeneficiario2:           generateRandomString(10),
		TipoCuentaBeneficiario2:       rand.Intn(10),
		CuentaBeneficiario2:           generateRandomString(10),
		RFCBeneficiario2:              generateRandomString(10),
		CURPBeneficiario2:             generateRandomString(10),
		TipoOperacion:                 generateRandomString(10),
		CausaDevolucion:               generateRandomString(10),
		InformacionFacturas:           generateRandomString(10),
		FolioInstruccionOriginal:      rand.Intn(1000),
		FolioPagoOriginal:             rand.Intn(1000),
		FechaOrdenTransferenciaOrig:   time.Now(),
		ClaveRastreoPagOrig:           generateRandomString(10),
		ReferenciaNumPagOrig:          rand.Intn(1000),
		TipoCtaOrdenantePagOrig:       rand.Intn(1000),
		CtaOrdenantePagOrig:           generateRandomString(10),
		ConceptoPagOrig:               generateRandomString(10),
		MontoPagOrig:                  rand.Float64() * 1000,
		MontoInteresesPagados:         rand.Float64() * 1000,
		IndicadorBeneficiarioRecursos: rand.Intn(1000),
		NumCelOrdenante:               generateRandomString(10),
		DigitoVerifDispoOrdenante:     rand.Intn(10),
		NumCelBeneficiario:            generateRandomString(10),
		DigitoVerifDispoBeneficiario:  rand.Intn(10),
		FolioEsqCobroDigital:          generateRandomString(10),
		PagoComisionPorTransferencia:  rand.Intn(1000),
		MontoComisionPorTransferencia: rand.Float64() * 1000,
		NumSerieCertificadoEnvio:      generateRandomString(10),
		FechaLimitePago:               time.Now(),
		UETRSwift:                     generateRandomString(10),
		CampoSwift1:                   generateRandomString(10),
		CampoSwift2:                   generateRandomString(10),
		FirmaDigitalCliente:           generateRandomString(10),
		UsuarioCaptura:                generateRandomString(10),
		InstruccionPago:               rand.Intn(1000),
		FolioOrdenInstruccion:         rand.Intn(1000),
		EstadoCore:                    2,
		EstadoBMX:                     2,
		CodigoError:                   0,
		DescripcionError:              generateRandomString(10),
		HuellaDigital:                 generateRandomString(10),
	}
}

func generateRandomString(length int) string {
	const charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
	seededRand := rand.New(rand.NewSource(time.Now().UnixNano()))
	b := make([]byte, length)
	for i := range b {
		b[i] = charset[seededRand.Intn(len(charset))]
	}
	return string(b)
}
